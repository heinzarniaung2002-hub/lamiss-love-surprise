LAMISS LOVE SURPRISE
1. Upload index.html to the root of a GitHub repository.
2. In the repository, open Settings > Pages.
3. Under Build and deployment, choose Deploy from a branch.
4. Choose main and /(root), then Save.
5. Wait for the Pages URL to appear. Share that URL with Lamiss.

To change the message, open index.html and search for the text you want to edit.
The website is a static HTML/CSS/JavaScript page and needs no installation or server.
